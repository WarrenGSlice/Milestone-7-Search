<?php
	//**************************************
    //*********Programmers Heading**********
    //*Warren Peterson - Blog Project -*****
    //*03/20/2020 - This is my own work*****
    //*GCU CST-126 ---**********************
    //*************************************/
    //***Blog variables, constructor and***
    //********getters and setters**********/
class Person{
    
    private $id;
    private $title;
    private $body;
    private $user_id;
    private $slug;
    private $views;
    private $image;
    private $published;
    private $created_at;
    private $updated_at;

    
    public function __construct($a, $b, $c, $d, $e, $f, $g, $h, $i, $j){
        $this->id = $a;
        $this->title = $b;
        $this->body = $c;
        $this->image = $d;
        $this->published = $e;
        $this->user_id = $f;
        $this->slug = $g;
        $this->views = $h;
        $this->created_at = $i;
        $this->updated_at = $j;
    }
    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @return mixed
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * @return mixed
     */
    public function getBody()
    {
        return $this->body;
    }

    /**
     * @param mixed $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @param mixed $first_name
     */
    public function setTitle($title)
    {
        $this->title = $title;
    }

    /**
     * @param mixed $last_name
     */
    public function setBody($body)
    {
        $this->body = $body;
    }
    /**
     * @param mixed $image
     */
    public function setImage($image)
    {
        $this->image = $image;
    }

    /**
     * @return mixed
     */
    public function getImage()
    {
        return $this->image;
    }
    /**
     * @param mixed $published
     */
    public function setPublished($published)
    {
        $this->published = $published;
    }

    /**
     * @return mixed
     */
    public function getPublished()
    {
        return $this->published;
    }
    /**
     * @param mixed $user_id
     */
    public function setUser_id($user_id)
    {
        $this->user_id = $user_id;
    }

    /**
     * @return mixed
     */
    public function getUser_id()
    {
        return $this->user_id;
    }
    /**
     * @return mixed
     */
    public function getSlug()
    {
        return $this->slug;
    }

    /**
     * @return mixed
     */
    public function getViews()
    {
        return $this->views;
    }
    /**
     * @return mixed
     */
    public function getCreated_at()
    {
        return $this->created_at;
    }

    /**
     * @return mixed
     */
    public function getUpdated_at()
    {
        return $this->updated_at;
    }
    /**
     * @param mixed $slug
     */
    public function setSlug($slug)
    {
        $this->slug = $slug;
    }

    /**
     * @param mixed $views
     */
    public function setViews($views)
    {
        $this->views = $views;
    }
     /**
     * @param mixed $created_at
     */
    public function setCreated_at($created_at)
    {
        $this->created_at = $created_at;
    }

    /**
     * @param mixed $updated_at
     */
    public function setUpdated_at($updated_at)
    {
        $this->updated_at = $updated_at;
    }
}
