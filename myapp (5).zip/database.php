<?php
	//**************************************
    //*********Programmers Heading**********
    //*Warren Peterson - Blog Project -*****
    //*03/20/2020 - This is my own work*****
    //*GCU CST-126 ---**********************
    //*************************************/
    //*************Config File*************/
class Database {
    private $dbservername = trial10-mysqldbserver.mysql.database.azure.com;
    private $dbusername = "Warren";
    private $dbpassword = "Techn9ne";
    private $dnname = "completeblogphp";
    
    function getConnection(){
        $conn = new mysqli($this->dbservername, $this->dbusername, $this->dbpassword, $this->dbname);
        
        if ($conn->connect_error){
            echo "Connection failed " .$conn->connect_error . "<br>";
        }else{
            return $conn;
        }
    }
}